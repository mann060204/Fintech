import { Shield, Heart, Link2, Award, MapPin, BellOff } from "lucide-react"

const features = [
  {
    icon: Shield,
    title: "Dynamic Trust Score",
    description:
      "Your score (300-1000) is built from payment history and social currency. Higher scores unlock better loan limits and peer endorsements.",
  },
  {
    icon: Heart,
    title: "Empathy AI Engine",
    description:
      "Our Context AI detects when friends are at sensitive locations and automatically suppresses payment reminders. Because timing matters.",
  },
  {
    icon: Link2,
    title: "Blockchain Agreements",
    description:
      "Replace vague promises with immutable, hashed digital contracts. Every agreement is verified and stored on-chain for transparency.",
  },
  {
    icon: Award,
    title: "Gamified Rewards",
    description:
      "Earn candy-themed achievements for on-time payments, helping friends, and building trust. Unlock Common, Premium, and Rare tiers.",
  },
  {
    icon: MapPin,
    title: "Location-Aware System",
    description:
      "Powered by Google Places API and Radar SDK, the platform understands real-world context to make smarter financial decisions.",
  },
  {
    icon: BellOff,
    title: "Smart Notifications",
    description:
      "Notifications that respect your life. The AI checks context before every nudge, ensuring no one gets a reminder at the wrong time.",
  },
]

export function FeaturesSection() {
  return (
    <section id="features" className="bg-card px-4 py-20 lg:px-8 lg:py-28">
      <div className="mx-auto max-w-7xl">
        <div className="text-center">
          <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-primary/20 bg-secondary px-4 py-1.5">
            <span className="text-xs font-medium text-secondary-foreground">Platform Features</span>
          </div>
          <h2
            className="text-balance text-3xl font-bold tracking-tight text-foreground sm:text-4xl"
            style={{ fontFamily: "var(--font-heading)" }}
          >
            Finance Meets Empathy
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-pretty text-base leading-relaxed text-muted-foreground">
            A fintech platform built on Node.js microservices with a hybrid
            persistence strategy. PostgreSQL for transactions, MongoDB for
            profiles. All powered by AI.
          </p>
        </div>

        <div className="mt-16 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {features.map((feature) => (
            <div
              key={feature.title}
              className="group rounded-2xl border border-border bg-background p-6 transition-all hover:border-primary/30 hover:shadow-lg hover:shadow-primary/5"
            >
              <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 transition-colors group-hover:bg-primary/15">
                <feature.icon className="h-6 w-6 text-primary" />
              </div>
              <h3 className="mb-2 text-lg font-semibold text-foreground">
                {feature.title}
              </h3>
              <p className="text-sm leading-relaxed text-muted-foreground">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
