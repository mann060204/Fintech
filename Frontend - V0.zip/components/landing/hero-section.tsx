import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight, Shield, Heart, TrendingUp } from "lucide-react"

export function HeroSection() {
  return (
    <section className="relative overflow-hidden bg-background px-4 pb-20 pt-16 lg:px-8 lg:pb-32 lg:pt-24">
      {/* Background decoration */}
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="absolute -right-40 -top-40 h-96 w-96 rounded-full bg-primary/5" />
        <div className="absolute -bottom-20 -left-20 h-72 w-72 rounded-full bg-accent/30" />
      </div>

      <div className="relative mx-auto max-w-7xl">
        <div className="flex flex-col items-center text-center">
          {/* Badge */}
          <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-primary/20 bg-secondary px-4 py-1.5">
            <div className="h-2 w-2 rounded-full bg-primary animate-pulse" />
            <span className="text-xs font-medium text-secondary-foreground">
              Powered by Context AI Engine
            </span>
          </div>

          {/* Heading */}
          <h1
            className="max-w-4xl text-balance text-4xl font-bold tracking-tight text-foreground sm:text-5xl lg:text-6xl xl:text-7xl"
            style={{ fontFamily: "var(--font-heading)" }}
          >
            Social Collateral for a{" "}
            <span className="text-primary">Trust-First</span>{" "}
            Financial Future
          </h1>

          {/* Subheading */}
          <p className="mt-6 max-w-2xl text-pretty text-base leading-relaxed text-muted-foreground sm:text-lg">
            Build your trust score, split expenses with friends, and unlock
            higher loan limits. Our AI-driven empathy engine understands when
            life happens and pauses reminders at the right moments.
          </p>

          {/* CTAs */}
          <div className="mt-10 flex flex-col gap-3 sm:flex-row sm:gap-4">
            <Button size="lg" asChild className="gap-2 px-8">
              <Link href="/auth/signup">
                Start Building Trust <ArrowRight className="h-4 w-4" />
              </Link>
            </Button>
            <Button size="lg" variant="outline" asChild className="gap-2 px-8">
              <Link href="#features">See How It Works</Link>
            </Button>
          </div>

          {/* Stats */}
          <div className="mt-16 grid grid-cols-3 gap-8 sm:gap-16">
            <div className="flex flex-col items-center gap-1">
              <span className="text-2xl font-bold text-foreground sm:text-3xl">50K+</span>
              <span className="text-xs text-muted-foreground sm:text-sm">Active Users</span>
            </div>
            <div className="flex flex-col items-center gap-1">
              <span className="text-2xl font-bold text-foreground sm:text-3xl">$12M+</span>
              <span className="text-xs text-muted-foreground sm:text-sm">Settled Safely</span>
            </div>
            <div className="flex flex-col items-center gap-1">
              <span className="text-2xl font-bold text-foreground sm:text-3xl">98%</span>
              <span className="text-xs text-muted-foreground sm:text-sm">Repayment Rate</span>
            </div>
          </div>

          {/* Dashboard Preview Card */}
          <div className="mt-16 w-full max-w-4xl">
            <div className="rounded-2xl border border-border bg-card p-4 shadow-xl shadow-primary/5 sm:p-6">
              <div className="grid gap-4 sm:grid-cols-3">
                {/* Trust Score */}
                <div className="flex flex-col items-center gap-3 rounded-xl bg-secondary p-5">
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                    <Shield className="h-6 w-6 text-primary" />
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-foreground">782</div>
                    <div className="text-xs font-medium text-muted-foreground">Trust Score</div>
                  </div>
                  <div className="h-2 w-full rounded-full bg-muted">
                    <div className="h-2 rounded-full bg-primary" style={{ width: "78%" }} />
                  </div>
                </div>

                {/* Empathy Status */}
                <div className="flex flex-col items-center gap-3 rounded-xl bg-secondary p-5">
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                    <Heart className="h-6 w-6 text-primary" />
                  </div>
                  <div className="text-center">
                    <div className="text-sm font-semibold text-foreground">Empathy Mode</div>
                    <div className="text-xs text-muted-foreground">Active &middot; 2 Suppressed</div>
                  </div>
                  <div className="rounded-full bg-accent px-3 py-1 text-xs font-medium text-accent-foreground">
                    AI Monitoring
                  </div>
                </div>

                {/* Active Agreements */}
                <div className="flex flex-col items-center gap-3 rounded-xl bg-secondary p-5">
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                    <TrendingUp className="h-6 w-6 text-primary" />
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-foreground">5</div>
                    <div className="text-xs font-medium text-muted-foreground">Active Agreements</div>
                  </div>
                  <div className="text-xs text-primary font-medium">
                    All Blockchain Verified
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
