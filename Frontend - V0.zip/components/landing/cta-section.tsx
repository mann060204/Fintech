import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight, Shield } from "lucide-react"

export function CTASection() {
  return (
    <section id="rewards" className="bg-background px-4 py-20 lg:px-8 lg:py-28">
      <div className="mx-auto max-w-7xl">
        {/* Rewards Preview */}
        <div className="mb-20">
          <div className="text-center mb-12">
            <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-primary/20 bg-secondary px-4 py-1.5">
              <span className="text-xs font-medium text-secondary-foreground">Gamified Rewards</span>
            </div>
            <h2
              className="text-balance text-3xl font-bold tracking-tight text-foreground sm:text-4xl"
              style={{ fontFamily: "var(--font-heading)" }}
            >
              Earn Rewards for Being Reliable
            </h2>
            <p className="mx-auto mt-4 max-w-2xl text-base text-muted-foreground leading-relaxed">
              Every on-time payment and trust-building action earns candy-themed
              achievements across three tiers.
            </p>
          </div>

          <div className="grid gap-6 sm:grid-cols-3 max-w-3xl mx-auto">
            {/* Common Tier */}
            <div className="rounded-2xl border border-border bg-card p-6 text-center transition-all hover:border-primary/30 hover:shadow-lg hover:shadow-primary/5">
              <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-secondary">
                <span className="text-2xl" role="img" aria-label="candy">
                  <svg className="h-8 w-8 text-muted-foreground" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10" /><path d="M8 12h8" /><path d="M12 8v8" /></svg>
                </span>
              </div>
              <h3 className="text-lg font-semibold text-foreground">Common</h3>
              <p className="mt-1 text-sm text-muted-foreground">First Steps</p>
              <div className="mt-4 flex flex-wrap justify-center gap-2">
                <span className="rounded-full bg-muted px-2.5 py-0.5 text-xs text-muted-foreground">5 Payments</span>
                <span className="rounded-full bg-muted px-2.5 py-0.5 text-xs text-muted-foreground">1 Group</span>
              </div>
            </div>

            {/* Premium Tier */}
            <div className="rounded-2xl border-2 border-primary bg-card p-6 text-center shadow-lg shadow-primary/10">
              <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/10">
                <Shield className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-lg font-semibold text-foreground">Premium</h3>
              <p className="mt-1 text-sm text-primary font-medium">Trust Builder</p>
              <div className="mt-4 flex flex-wrap justify-center gap-2">
                <span className="rounded-full bg-primary/10 px-2.5 py-0.5 text-xs text-primary font-medium">25 Payments</span>
                <span className="rounded-full bg-primary/10 px-2.5 py-0.5 text-xs text-primary font-medium">Score 600+</span>
              </div>
            </div>

            {/* Rare CEO Tier */}
            <div className="rounded-2xl border border-border bg-card p-6 text-center transition-all hover:border-primary/30 hover:shadow-lg hover:shadow-primary/5">
              <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-accent">
                <svg className="h-8 w-8 text-accent-foreground" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" /></svg>
              </div>
              <h3 className="text-lg font-semibold text-foreground">Rare</h3>
              <p className="mt-1 text-sm text-muted-foreground">CEO Endorsement</p>
              <div className="mt-4 flex flex-wrap justify-center gap-2">
                <span className="rounded-full bg-muted px-2.5 py-0.5 text-xs text-muted-foreground">100 Payments</span>
                <span className="rounded-full bg-muted px-2.5 py-0.5 text-xs text-muted-foreground">Score 900+</span>
              </div>
            </div>
          </div>
        </div>

        {/* CTA Banner */}
        <div className="rounded-3xl bg-primary px-6 py-16 text-center sm:px-12 lg:py-20">
          <h2
            className="text-balance text-3xl font-bold tracking-tight text-primary-foreground sm:text-4xl"
            style={{ fontFamily: "var(--font-heading)" }}
          >
            Ready to Build Trust-First Finance?
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-pretty text-base text-primary-foreground/80 leading-relaxed">
            Join thousands of users who have replaced vague promises with
            blockchain-verified agreements and AI-powered empathy.
          </p>
          <div className="mt-8 flex flex-col justify-center gap-3 sm:flex-row sm:gap-4">
            <Button
              size="lg"
              variant="secondary"
              asChild
              className="gap-2 px-8 bg-primary-foreground text-primary hover:bg-primary-foreground/90"
            >
              <Link href="/auth/signup">
                Get Started Free <ArrowRight className="h-4 w-4" />
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}
