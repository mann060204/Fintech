"use client"

import { Shield, TrendingUp, Users, Clock } from "lucide-react"

const scoreFactors = [
  {
    icon: Clock,
    label: "Payment History",
    value: "45%",
    description: "On-time payments and settlement speed",
  },
  {
    icon: Users,
    label: "Social Currency",
    value: "25%",
    description: "Peer endorsements and group reliability",
  },
  {
    icon: TrendingUp,
    label: "Financial Behavior",
    value: "20%",
    description: "Spending patterns and consistency",
  },
  {
    icon: Shield,
    label: "Verification Level",
    value: "10%",
    description: "Identity verification and KYC completion",
  },
]

export function TrustScoreSection() {
  return (
    <section id="trust-score" className="bg-background px-4 py-20 lg:px-8 lg:py-28">
      <div className="mx-auto max-w-7xl">
        <div className="grid gap-12 lg:grid-cols-2 lg:gap-20 items-center">
          {/* Left: Trust Score Visualization */}
          <div className="flex items-center justify-center">
            <div className="relative">
              {/* Main score circle */}
              <div className="flex h-72 w-72 flex-col items-center justify-center rounded-full border-4 border-primary/20 bg-card shadow-2xl shadow-primary/10 sm:h-80 sm:w-80">
                <span className="text-sm font-medium text-muted-foreground">
                  Your Trust Score
                </span>
                <span className="text-6xl font-bold text-foreground sm:text-7xl">
                  782
                </span>
                <span className="mt-1 text-sm font-medium text-primary">
                  Excellent
                </span>
                <div className="mt-3 flex items-center gap-1 text-primary">
                  <TrendingUp className="h-4 w-4" />
                  <span className="text-xs font-medium">+24 this month</span>
                </div>
              </div>

              {/* Floating badges */}
              <div className="absolute -right-4 top-8 rounded-xl border border-border bg-card px-3 py-2 shadow-lg">
                <div className="flex items-center gap-2">
                  <div className="h-2 w-2 rounded-full bg-primary" />
                  <span className="text-xs font-medium text-foreground">Verified</span>
                </div>
              </div>
              <div className="absolute -left-4 bottom-16 rounded-xl border border-border bg-card px-3 py-2 shadow-lg">
                <div className="flex items-center gap-2">
                  <div className="h-2 w-2 rounded-full bg-chart-5" />
                  <span className="text-xs font-medium text-foreground">Top 15%</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right: Score Breakdown */}
          <div>
            <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-primary/20 bg-secondary px-4 py-1.5">
              <span className="text-xs font-medium text-secondary-foreground">Social Collateral</span>
            </div>
            <h2
              className="text-balance text-3xl font-bold tracking-tight text-foreground sm:text-4xl"
              style={{ fontFamily: "var(--font-heading)" }}
            >
              Your Trust Unlocks More
            </h2>
            <p className="mt-4 text-pretty text-base leading-relaxed text-muted-foreground">
              Your Dynamic Trust Score ranges from 300 to 1000, built on
              real payment behavior and social endorsements. Higher scores
              unlock bigger loan limits and premium features.
            </p>

            <div className="mt-8 flex flex-col gap-4">
              {scoreFactors.map((factor) => (
                <div
                  key={factor.label}
                  className="flex items-start gap-4 rounded-xl border border-border bg-card p-4 transition-colors hover:border-primary/20"
                >
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/10">
                    <factor.icon className="h-5 w-5 text-primary" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-semibold text-foreground">
                        {factor.label}
                      </span>
                      <span className="text-sm font-bold text-primary">
                        {factor.value}
                      </span>
                    </div>
                    <p className="mt-0.5 text-xs text-muted-foreground">
                      {factor.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
