import { Heart, BellOff, MapPin, Eye, Building2, GraduationCap, Siren } from "lucide-react"

const suppressionZones = [
  { icon: Building2, label: "Hospitals", description: "Medical emergencies come first" },
  { icon: Heart, label: "Funeral Homes", description: "Respecting moments of grief" },
  { icon: Siren, label: "Police Stations", description: "Legal situations need space" },
  { icon: GraduationCap, label: "Colleges", description: "Focus on what matters" },
]

export function EmpathySection() {
  return (
    <section id="empathy-ai" className="bg-card px-4 py-20 lg:px-8 lg:py-28">
      <div className="mx-auto max-w-7xl">
        <div className="grid gap-12 lg:grid-cols-2 lg:gap-20 items-center">
          {/* Left: Content */}
          <div>
            <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-primary/20 bg-secondary px-4 py-1.5">
              <Heart className="h-3 w-3 text-primary" />
              <span className="text-xs font-medium text-secondary-foreground">Context AI Engine</span>
            </div>
            <h2
              className="text-balance text-3xl font-bold tracking-tight text-foreground sm:text-4xl"
              style={{ fontFamily: "var(--font-heading)" }}
            >
              AI That Understands When Life Happens
            </h2>
            <p className="mt-4 text-pretty text-base leading-relaxed text-muted-foreground">
              Our empathy engine uses real-time location data from Google
              Places API and Radar SDK to detect sensitive situations. When
              someone is going through a tough time, the system pauses all
              payment reminders automatically.
            </p>

            {/* Workflow visualization */}
            <div className="mt-8 flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground text-xs font-bold">
                  1
                </div>
                <div className="flex-1 rounded-lg bg-secondary px-4 py-2.5">
                  <span className="text-sm font-medium text-foreground">CheckLocation</span>
                  <span className="text-xs text-muted-foreground ml-2">Notification triggered</span>
                </div>
              </div>
              <div className="ml-4 h-4 w-px bg-primary/30" />
              <div className="flex items-center gap-3">
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground text-xs font-bold">
                  2
                </div>
                <div className="flex-1 rounded-lg bg-secondary px-4 py-2.5">
                  <span className="text-sm font-medium text-foreground">Analyze Context</span>
                  <span className="text-xs text-muted-foreground ml-2">{'Category === "Sensitive"?'}</span>
                </div>
              </div>
              <div className="ml-4 h-4 w-px bg-primary/30" />
              <div className="flex items-center gap-3">
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-accent text-accent-foreground text-xs font-bold">
                  3
                </div>
                <div className="flex-1 rounded-lg border-2 border-primary/20 bg-primary/5 px-4 py-2.5">
                  <span className="text-sm font-medium text-primary">Suppressed</span>
                  <span className="text-xs text-muted-foreground ml-2">Reminder paused with empathy</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right: Suppression Zones */}
          <div className="flex flex-col gap-4">
            {/* Status card */}
            <div className="rounded-2xl border border-border bg-background p-6 shadow-lg shadow-primary/5">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <BellOff className="h-5 w-5 text-primary" />
                  <span className="text-sm font-semibold text-foreground">Active Reminders</span>
                </div>
                <div className="rounded-full bg-accent px-3 py-1 text-xs font-medium text-accent-foreground">
                  2 Suppressed
                </div>
              </div>

              {/* Mock notification */}
              <div className="rounded-xl border border-primary/20 bg-primary/5 p-4 mb-4">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/10">
                    <Heart className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <div className="text-sm font-medium text-foreground">Notification Suppressed</div>
                    <div className="text-xs text-muted-foreground">Alex is in a sensitive zone -- reminders paused</div>
                  </div>
                </div>
              </div>

              {/* AI toggle */}
              <div className="flex items-center justify-between rounded-xl bg-muted p-4">
                <div className="flex items-center gap-3">
                  <Eye className="h-5 w-5 text-primary" />
                  <div>
                    <div className="text-sm font-medium text-foreground">Empathy Mode</div>
                    <div className="text-xs text-muted-foreground">Context AI Engine active</div>
                  </div>
                </div>
                <div className="h-6 w-11 rounded-full bg-primary p-0.5">
                  <div className="h-5 w-5 translate-x-5 rounded-full bg-primary-foreground shadow-sm" />
                </div>
              </div>
            </div>

            {/* Suppression zone cards */}
            <div className="grid grid-cols-2 gap-3">
              {suppressionZones.map((zone) => (
                <div
                  key={zone.label}
                  className="flex items-center gap-3 rounded-xl border border-border bg-background p-4 transition-colors hover:border-primary/20"
                >
                  <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-primary/10">
                    <zone.icon className="h-4 w-4 text-primary" />
                  </div>
                  <div>
                    <div className="text-sm font-medium text-foreground">{zone.label}</div>
                    <div className="text-xs text-muted-foreground">{zone.description}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
