import Link from "next/link"
import { Shield } from "lucide-react"

export function Footer() {
  return (
    <footer className="border-t border-border bg-card px-4 py-12 lg:px-8">
      <div className="mx-auto max-w-7xl">
        <div className="flex flex-col gap-8 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
              <Shield className="h-4 w-4 text-primary-foreground" />
            </div>
            <span className="text-sm font-bold text-foreground" style={{ fontFamily: "var(--font-heading)" }}>
              Project Platform
            </span>
          </div>

          <div className="flex flex-wrap gap-6">
            <Link href="#features" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              Features
            </Link>
            <Link href="#trust-score" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              Trust Score
            </Link>
            <Link href="#empathy-ai" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              Empathy AI
            </Link>
            <Link href="#rewards" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              Rewards
            </Link>
          </div>

          <p className="text-xs text-muted-foreground">
            Built with Node.js microservices &middot; PostgreSQL + MongoDB
          </p>
        </div>
      </div>
    </footer>
  )
}
