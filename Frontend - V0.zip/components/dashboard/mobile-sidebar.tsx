"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import {
  Shield,
  LayoutDashboard,
  Users,
  UserCircle,
  Activity,
  FileText,
  Award,
  Settings,
  Bell,
  Heart,
  MapPin,
} from "lucide-react"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"

const navItems = [
  { icon: LayoutDashboard, label: "Dashboard", href: "/dashboard" },
  { icon: Activity, label: "Activity", href: "/dashboard/activity" },
  { icon: Users, label: "Friends", href: "/dashboard/friends" },
  { icon: UserCircle, label: "Groups", href: "/dashboard/groups" },
  { icon: FileText, label: "Agreements", href: "/dashboard/agreements" },
  { icon: Award, label: "Rewards", href: "/dashboard/rewards" },
  { icon: Heart, label: "Empathy AI", href: "/dashboard/empathy" },
  { icon: MapPin, label: "Location", href: "/dashboard/location" },
  { icon: Bell, label: "Notifications", href: "/dashboard/notifications" },
  { icon: Settings, label: "Settings", href: "/dashboard/settings" },
]

export function DashboardMobileSidebar() {
  const pathname = usePathname()

  return (
    <div className="flex h-full flex-col">
      {/* Logo */}
      <div className="flex h-16 items-center gap-2 border-b border-sidebar-border px-5">
        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-sidebar-primary">
          <Shield className="h-4 w-4 text-sidebar-primary-foreground" />
        </div>
        <span className="text-sm font-bold text-sidebar-foreground" style={{ fontFamily: "var(--font-heading)" }}>
          Project Platform
        </span>
      </div>

      <nav className="flex-1 overflow-auto px-3 py-4">
        <div className="flex flex-col gap-0.5">
          {navItems.map((item) => {
            const isActive = pathname === item.href
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "flex items-center gap-3 rounded-lg px-2.5 py-2.5 text-sm font-medium transition-colors",
                  isActive
                    ? "bg-sidebar-accent text-sidebar-primary"
                    : "text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground"
                )}
              >
                <item.icon className="h-4 w-4" />
                {item.label}
              </Link>
            )
          })}
        </div>
      </nav>

      <div className="border-t border-sidebar-border p-3">
        <div className="flex items-center gap-3 px-2 py-2">
          <Avatar className="h-8 w-8">
            <AvatarFallback className="bg-sidebar-primary text-sidebar-primary-foreground text-xs">JP</AvatarFallback>
          </Avatar>
          <div>
            <p className="text-sm font-medium text-sidebar-foreground">John Parker</p>
            <p className="text-[10px] text-sidebar-foreground/50">Trust Score: 782</p>
          </div>
        </div>
      </div>
    </div>
  )
}
