"use client"

import { Shield, TrendingUp, Heart, BellOff, Award, ArrowUpRight, ArrowDownRight } from "lucide-react"
import { Progress } from "@/components/ui/progress"

export function FinancialHealth() {
  return (
    <div className="flex flex-col gap-5">
      {/* Trust Score Card */}
      <div className="rounded-2xl border border-border bg-card p-5">
        <div className="flex items-center gap-2 mb-4">
          <Shield className="h-4 w-4 text-primary" />
          <h3 className="text-sm font-semibold text-foreground">Trust Score</h3>
        </div>
        <div className="flex items-end gap-2">
          <span className="text-4xl font-bold text-foreground">782</span>
          <div className="mb-1 flex items-center gap-1 text-chart-5">
            <TrendingUp className="h-3.5 w-3.5" />
            <span className="text-xs font-medium">+24</span>
          </div>
        </div>
        <div className="mt-3">
          <div className="flex justify-between text-[10px] text-muted-foreground mb-1">
            <span>300</span>
            <span>Excellent</span>
            <span>1000</span>
          </div>
          <div className="h-2 w-full rounded-full bg-muted overflow-hidden">
            <div
              className="h-full rounded-full bg-primary transition-all"
              style={{ width: "69%" }}
            />
          </div>
        </div>
        <div className="mt-4 grid grid-cols-2 gap-3">
          <div className="rounded-lg bg-muted p-2.5 text-center">
            <p className="text-[10px] text-muted-foreground">Payment</p>
            <p className="text-sm font-bold text-foreground">96%</p>
          </div>
          <div className="rounded-lg bg-muted p-2.5 text-center">
            <p className="text-[10px] text-muted-foreground">Social</p>
            <p className="text-sm font-bold text-foreground">88%</p>
          </div>
        </div>
      </div>

      {/* Empathy Status */}
      <div className="rounded-2xl border border-primary/20 bg-primary/5 p-5">
        <div className="flex items-center gap-2 mb-3">
          <Heart className="h-4 w-4 text-primary" />
          <h3 className="text-sm font-semibold text-foreground">Empathy Status</h3>
        </div>
        <div className="flex items-center gap-2 mb-3">
          <BellOff className="h-3.5 w-3.5 text-primary" />
          <span className="text-xs text-foreground font-medium">2 Notifications Suppressed</span>
        </div>
        <div className="rounded-lg bg-card p-3">
          <p className="text-xs text-muted-foreground">
            Alex K. is near a hospital. Payment reminder for $21.00 has been paused.
          </p>
          <p className="mt-1.5 text-[10px] text-primary font-medium">
            Context AI Engine active
          </p>
        </div>
      </div>

      {/* Balance Summary */}
      <div className="rounded-2xl border border-border bg-card p-5">
        <h3 className="text-sm font-semibold text-foreground mb-4">Balance Summary</h3>
        <div className="flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ArrowUpRight className="h-4 w-4 text-chart-5" />
              <span className="text-xs text-muted-foreground">You are owed</span>
            </div>
            <span className="text-sm font-bold text-chart-5">+$146.31</span>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ArrowDownRight className="h-4 w-4 text-destructive-foreground" />
              <span className="text-xs text-muted-foreground">You owe</span>
            </div>
            <span className="text-sm font-bold text-destructive-foreground">-$821.00</span>
          </div>
          <div className="border-t border-border pt-3 flex items-center justify-between">
            <span className="text-xs font-medium text-foreground">Net Balance</span>
            <span className="text-sm font-bold text-destructive-foreground">-$674.69</span>
          </div>
        </div>
      </div>

      {/* Rewards Preview */}
      <div className="rounded-2xl border border-border bg-card p-5">
        <div className="flex items-center gap-2 mb-3">
          <Award className="h-4 w-4 text-primary" />
          <h3 className="text-sm font-semibold text-foreground">Next Reward</h3>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10">
            <Award className="h-5 w-5 text-primary" />
          </div>
          <div className="flex-1">
            <p className="text-sm font-medium text-foreground">Premium Tier</p>
            <p className="text-[10px] text-muted-foreground">3 more on-time payments</p>
          </div>
        </div>
        <Progress value={73} className="mt-3 h-1.5" />
        <p className="mt-1.5 text-right text-[10px] text-muted-foreground">73% complete</p>
      </div>
    </div>
  )
}
