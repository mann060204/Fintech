"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import {
  Shield,
  LayoutDashboard,
  Users,
  UserCircle,
  Activity,
  FileText,
  Award,
  Settings,
  Bell,
  Heart,
  MapPin,
  ChevronDown,
} from "lucide-react"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { useState } from "react"

const navGroups = [
  {
    label: "Overview",
    items: [
      { icon: LayoutDashboard, label: "Dashboard", href: "/dashboard" },
      { icon: Activity, label: "Activity", href: "/dashboard/activity" },
    ],
  },
  {
    label: "Social",
    items: [
      { icon: Users, label: "Friends", href: "/dashboard/friends" },
      { icon: UserCircle, label: "Groups", href: "/dashboard/groups" },
    ],
  },
  {
    label: "Finance",
    items: [
      { icon: FileText, label: "Agreements", href: "/dashboard/agreements" },
      { icon: Award, label: "Rewards", href: "/dashboard/rewards" },
    ],
  },
  {
    label: "AI & Settings",
    items: [
      { icon: Heart, label: "Empathy AI", href: "/dashboard/empathy" },
      { icon: MapPin, label: "Location Settings", href: "/dashboard/location" },
      { icon: Bell, label: "Notifications", href: "/dashboard/notifications" },
      { icon: Settings, label: "Settings", href: "/dashboard/settings" },
    ],
  },
]

const friends = [
  { name: "Sarah M.", status: "online", owes: "+$45.00" },
  { name: "Alex K.", status: "sensitive", owes: "-$120.00" },
  { name: "Jordan R.", status: "online", owes: "+$22.50" },
  { name: "Taylor P.", status: "offline", owes: "$0.00" },
]

export function DashboardSidebar() {
  const pathname = usePathname()
  const [showFriends, setShowFriends] = useState(true)

  return (
    <aside className="hidden w-64 shrink-0 flex-col border-r border-sidebar-border bg-sidebar lg:flex">
      {/* Logo */}
      <div className="flex h-16 items-center gap-2 border-b border-sidebar-border px-5">
        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-sidebar-primary">
          <Shield className="h-4 w-4 text-sidebar-primary-foreground" />
        </div>
        <span className="text-sm font-bold text-sidebar-foreground" style={{ fontFamily: "var(--font-heading)" }}>
          Project Platform
        </span>
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-auto px-3 py-4">
        {navGroups.map((group) => (
          <div key={group.label} className="mb-5">
            <p className="mb-2 px-2 text-[10px] font-semibold uppercase tracking-wider text-sidebar-foreground/40">
              {group.label}
            </p>
            <div className="flex flex-col gap-0.5">
              {group.items.map((item) => {
                const isActive = pathname === item.href
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    className={cn(
                      "flex items-center gap-3 rounded-lg px-2.5 py-2 text-sm font-medium transition-colors",
                      isActive
                        ? "bg-sidebar-accent text-sidebar-primary"
                        : "text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground"
                    )}
                  >
                    <item.icon className="h-4 w-4" />
                    {item.label}
                  </Link>
                )
              })}
            </div>
          </div>
        ))}

        {/* Friends quick list */}
        <div className="mb-4">
          <button
            className="mb-2 flex w-full items-center justify-between px-2"
            onClick={() => setShowFriends(!showFriends)}
          >
            <p className="text-[10px] font-semibold uppercase tracking-wider text-sidebar-foreground/40">
              Friends
            </p>
            <ChevronDown className={cn("h-3 w-3 text-sidebar-foreground/40 transition-transform", showFriends && "rotate-180")} />
          </button>
          {showFriends && (
            <div className="flex flex-col gap-1">
              {friends.map((friend) => (
                <div
                  key={friend.name}
                  className="flex items-center gap-2.5 rounded-lg px-2.5 py-2 transition-colors hover:bg-sidebar-accent/50"
                >
                  <div className="relative">
                    <Avatar className="h-7 w-7">
                      <AvatarFallback className="bg-sidebar-accent text-sidebar-foreground text-[10px]">
                        {friend.name.split(" ").map(n => n[0]).join("")}
                      </AvatarFallback>
                    </Avatar>
                    <div
                      className={cn(
                        "absolute -bottom-0.5 -right-0.5 h-2.5 w-2.5 rounded-full border-2 border-sidebar",
                        friend.status === "online" && "bg-chart-5",
                        friend.status === "sensitive" && "bg-primary",
                        friend.status === "offline" && "bg-sidebar-foreground/30"
                      )}
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <span className="truncate text-xs font-medium text-sidebar-foreground">
                        {friend.name}
                      </span>
                      <span className={cn(
                        "text-[10px] font-medium",
                        friend.owes.startsWith("+") ? "text-chart-5" : friend.owes.startsWith("-") ? "text-destructive-foreground" : "text-sidebar-foreground/50"
                      )}>
                        {friend.owes}
                      </span>
                    </div>
                    {friend.status === "sensitive" && (
                      <span className="text-[10px] text-primary/80">In a sensitive zone</span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </nav>

      {/* Profile */}
      <div className="border-t border-sidebar-border p-3">
        <div className="flex items-center gap-3 rounded-lg px-2 py-2">
          <Avatar className="h-8 w-8">
            <AvatarFallback className="bg-sidebar-primary text-sidebar-primary-foreground text-xs">
              JP
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <p className="truncate text-sm font-medium text-sidebar-foreground">John Parker</p>
            <p className="truncate text-[10px] text-sidebar-foreground/50">Trust Score: 782</p>
          </div>
        </div>
      </div>
    </aside>
  )
}
