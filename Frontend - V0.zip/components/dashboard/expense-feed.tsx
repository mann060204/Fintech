"use client"

import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import {
  ShoppingCart,
  Home,
  Utensils,
  Car,
  Zap,
  Heart,
  BellOff,
} from "lucide-react"
import { cn } from "@/lib/utils"

const expenses = [
  {
    id: 1,
    description: "Groceries at Whole Foods",
    amount: 86.42,
    paidBy: "You",
    splitWith: ["Sarah M.", "Alex K."],
    date: "Today",
    category: "shopping",
    icon: ShoppingCart,
    yourShare: 28.81,
    direction: "owed",
  },
  {
    id: 2,
    description: "Monthly Rent - Feb",
    amount: 2400.0,
    paidBy: "Jordan R.",
    splitWith: ["You", "Jordan R.", "Taylor P."],
    date: "Yesterday",
    category: "housing",
    icon: Home,
    yourShare: 800.0,
    direction: "owe",
  },
  {
    id: 3,
    description: "Dinner at Nobu",
    amount: 145.0,
    paidBy: "You",
    splitWith: ["Sarah M."],
    date: "Feb 19",
    category: "food",
    icon: Utensils,
    yourShare: 72.5,
    direction: "owed",
  },
  {
    id: 4,
    description: "Uber to Airport",
    amount: 42.0,
    paidBy: "Alex K.",
    splitWith: ["You", "Alex K."],
    date: "Feb 18",
    category: "transport",
    icon: Car,
    yourShare: 21.0,
    direction: "owe",
    empathySuppressed: true,
  },
  {
    id: 5,
    description: "Electricity Bill - Feb",
    amount: 110.0,
    paidBy: "You",
    splitWith: ["Taylor P."],
    date: "Feb 17",
    category: "utilities",
    icon: Zap,
    yourShare: 55.0,
    direction: "owed",
  },
]

export function ExpenseFeed() {
  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center justify-between">
        <h2
          className="text-lg font-bold text-foreground"
          style={{ fontFamily: "var(--font-heading)" }}
        >
          Recent Expenses
        </h2>
        <div className="flex gap-2">
          <Badge variant="secondary" className="cursor-pointer">All</Badge>
          <Badge variant="outline" className="cursor-pointer">You Owe</Badge>
          <Badge variant="outline" className="cursor-pointer">Owed to You</Badge>
        </div>
      </div>

      <div className="flex flex-col gap-3">
        {expenses.map((expense) => (
          <div
            key={expense.id}
            className={cn(
              "rounded-xl border border-border bg-card p-4 transition-all hover:border-primary/20 hover:shadow-sm",
              expense.empathySuppressed && "border-primary/20 bg-primary/5"
            )}
          >
            {expense.empathySuppressed && (
              <div className="mb-3 flex items-center gap-2 rounded-lg bg-primary/10 px-3 py-1.5">
                <BellOff className="h-3.5 w-3.5 text-primary" />
                <span className="text-xs font-medium text-primary">
                  Reminder suppressed -- Alex is in a sensitive zone
                </span>
                <Heart className="ml-auto h-3.5 w-3.5 text-primary" />
              </div>
            )}

            <div className="flex items-start gap-3">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-muted">
                <expense.icon className="h-5 w-5 text-muted-foreground" />
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <p className="text-sm font-semibold text-foreground">
                      {expense.description}
                    </p>
                    <p className="mt-0.5 text-xs text-muted-foreground">
                      Paid by{" "}
                      <span className="font-medium text-foreground">
                        {expense.paidBy}
                      </span>
                      {" "}&middot; {expense.date}
                    </p>
                  </div>
                  <div className="text-right shrink-0">
                    <p className="text-sm font-bold text-foreground">
                      ${expense.amount.toFixed(2)}
                    </p>
                    <p
                      className={cn(
                        "text-xs font-medium",
                        expense.direction === "owed"
                          ? "text-chart-5"
                          : "text-destructive-foreground"
                      )}
                    >
                      {expense.direction === "owed" ? "+" : "-"}$
                      {expense.yourShare.toFixed(2)}
                    </p>
                  </div>
                </div>

                <div className="mt-2 flex items-center gap-1.5">
                  <span className="text-[10px] text-muted-foreground">Split with:</span>
                  <div className="flex -space-x-1">
                    {expense.splitWith.map((person) => (
                      <Avatar key={person} className="h-5 w-5 border border-card">
                        <AvatarFallback className="bg-muted text-[8px] text-muted-foreground">
                          {person.split(" ").map(n => n[0]).join("")}
                        </AvatarFallback>
                      </Avatar>
                    ))}
                  </div>
                  <span className="text-[10px] text-muted-foreground">
                    {expense.splitWith.join(", ")}
                  </span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
