"use client"

import { Bell, Search, Plus, Menu, Shield } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Sheet, SheetContent, SheetTrigger, SheetTitle } from "@/components/ui/sheet"
import { DashboardMobileSidebar } from "@/components/dashboard/mobile-sidebar"

export function DashboardHeader() {
  return (
    <header className="flex h-16 items-center justify-between border-b border-border bg-card px-4 lg:px-6">
      <div className="flex items-center gap-3">
        {/* Mobile menu */}
        <Sheet>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon" className="lg:hidden">
              <Menu className="h-5 w-5" />
              <span className="sr-only">Open menu</span>
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-72 p-0 bg-sidebar">
            <SheetTitle className="sr-only">Navigation Menu</SheetTitle>
            <DashboardMobileSidebar />
          </SheetContent>
        </Sheet>

        {/* Mobile logo */}
        <div className="flex items-center gap-2 lg:hidden">
          <div className="flex h-7 w-7 items-center justify-center rounded-md bg-primary">
            <Shield className="h-3.5 w-3.5 text-primary-foreground" />
          </div>
        </div>

        {/* Search */}
        <div className="relative hidden sm:block">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search expenses, friends, groups..."
            className="h-9 w-64 bg-muted/50 pl-9 text-sm border-none"
          />
        </div>
      </div>

      <div className="flex items-center gap-2">
        <Button size="sm" className="gap-1.5 hidden sm:flex">
          <Plus className="h-4 w-4" />
          Add Expense
        </Button>
        <Button size="icon" variant="ghost" className="sm:hidden">
          <Plus className="h-5 w-5" />
          <span className="sr-only">Add expense</span>
        </Button>

        <Button variant="ghost" size="icon" className="relative">
          <Bell className="h-5 w-5" />
          <span className="sr-only">Notifications</span>
          <span className="absolute right-1.5 top-1.5 h-2 w-2 rounded-full bg-primary" />
        </Button>

        <Avatar className="h-8 w-8 lg:hidden">
          <AvatarFallback className="bg-primary text-primary-foreground text-xs">JP</AvatarFallback>
        </Avatar>
      </div>
    </header>
  )
}
