import { ArrowUpRight, ArrowDownRight, Users, FileText } from "lucide-react"

const stats = [
  {
    label: "You Are Owed",
    value: "$146.31",
    change: "+$22.50 today",
    icon: ArrowUpRight,
    positive: true,
  },
  {
    label: "You Owe",
    value: "$821.00",
    change: "2 pending",
    icon: ArrowDownRight,
    positive: false,
  },
  {
    label: "Active Groups",
    value: "4",
    change: "12 members",
    icon: Users,
    positive: true,
  },
  {
    label: "Agreements",
    value: "5",
    change: "All verified",
    icon: FileText,
    positive: true,
  },
]

export function DashboardOverview() {
  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
      {stats.map((stat) => (
        <div
          key={stat.label}
          className="rounded-xl border border-border bg-card p-4 transition-all hover:border-primary/20"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-medium text-muted-foreground">
              {stat.label}
            </span>
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-muted">
              <stat.icon className="h-4 w-4 text-muted-foreground" />
            </div>
          </div>
          <p className="text-2xl font-bold text-foreground">{stat.value}</p>
          <p className={`mt-1 text-xs font-medium ${stat.positive ? "text-chart-5" : "text-destructive-foreground"}`}>
            {stat.change}
          </p>
        </div>
      ))}
    </div>
  )
}
