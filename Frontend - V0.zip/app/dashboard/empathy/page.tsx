"use client"

import { useState } from "react"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import {
  Heart,
  BellOff,
  Bell,
  MapPin,
  Eye,
  Building2,
  GraduationCap,
  Siren,
  Shield,
  Clock,
  CheckCircle2,
} from "lucide-react"
import { cn } from "@/lib/utils"

const suppressedNotifications = [
  {
    id: 1,
    friend: "Alex K.",
    initials: "AK",
    amount: "$21.00",
    reason: "Near St. Luke's Hospital",
    zone: "Hospital",
    zoneIcon: Building2,
    time: "2 hours ago",
    originalReminder: "Uber to Airport split",
  },
  {
    id: 2,
    friend: "Jordan R.",
    initials: "JR",
    amount: "$45.00",
    reason: "Near City College campus",
    zone: "College",
    zoneIcon: GraduationCap,
    time: "5 hours ago",
    originalReminder: "Dinner split payment",
  },
]

const recentDecisions = [
  {
    id: 1,
    action: "Suppressed",
    friend: "Alex K.",
    location: "Hospital Zone",
    time: "2h ago",
    status: "active",
  },
  {
    id: 2,
    action: "Sent",
    friend: "Sarah M.",
    location: "Home (Safe)",
    time: "3h ago",
    status: "sent",
  },
  {
    id: 3,
    action: "Suppressed",
    friend: "Jordan R.",
    location: "College Zone",
    time: "5h ago",
    status: "active",
  },
  {
    id: 4,
    action: "Sent",
    friend: "Taylor P.",
    location: "Office (Safe)",
    time: "1d ago",
    status: "sent",
  },
  {
    id: 5,
    action: "Suppressed",
    friend: "Morgan L.",
    location: "Police Station",
    time: "2d ago",
    status: "resolved",
  },
]

const sensitiveZones = [
  { icon: Building2, label: "Hospitals", enabled: true, count: 3 },
  { icon: Heart, label: "Funeral Homes", enabled: true, count: 1 },
  { icon: Siren, label: "Police Stations", enabled: true, count: 2 },
  { icon: GraduationCap, label: "Colleges", enabled: false, count: 5 },
]

export default function EmpathyPage() {
  const [empathyMode, setEmpathyMode] = useState(true)
  const [zones, setZones] = useState(sensitiveZones)

  const toggleZone = (index: number) => {
    setZones(prev => prev.map((z, i) =>
      i === index ? { ...z, enabled: !z.enabled } : z
    ))
  }

  return (
    <div className="flex flex-col gap-6 p-4 lg:p-6">
      {/* Header */}
      <div>
        <h1
          className="text-2xl font-bold text-foreground"
          style={{ fontFamily: "var(--font-heading)" }}
        >
          Empathy AI Engine
        </h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Location-aware notification system powered by the Context AI Engine
        </p>
      </div>

      {/* Master Toggle */}
      <div className="rounded-2xl border-2 border-primary/20 bg-primary/5 p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10">
              <Heart className="h-6 w-6 text-primary" />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-foreground">Empathy Mode</h2>
              <p className="text-sm text-muted-foreground">
                {empathyMode
                  ? "AI is actively monitoring friend locations for sensitive contexts"
                  : "All payment reminders will be sent regardless of context"}
              </p>
            </div>
          </div>
          <Switch
            checked={empathyMode}
            onCheckedChange={setEmpathyMode}
            className="data-[state=checked]:bg-primary"
          />
        </div>

        {empathyMode && (
          <div className="mt-4 grid grid-cols-3 gap-3">
            <div className="rounded-lg bg-card p-3 text-center">
              <p className="text-2xl font-bold text-foreground">2</p>
              <p className="text-[10px] text-muted-foreground">Active Suppressions</p>
            </div>
            <div className="rounded-lg bg-card p-3 text-center">
              <p className="text-2xl font-bold text-foreground">47</p>
              <p className="text-[10px] text-muted-foreground">Total Suppressed</p>
            </div>
            <div className="rounded-lg bg-card p-3 text-center">
              <p className="text-2xl font-bold text-foreground">98%</p>
              <p className="text-[10px] text-muted-foreground">Accuracy Rate</p>
            </div>
          </div>
        )}
      </div>

      <div className="grid gap-6 lg:grid-cols-[1fr_380px]">
        {/* Left: Activity */}
        <div className="flex flex-col gap-6">
          {/* Currently Suppressed */}
          <div>
            <h3 className="mb-3 flex items-center gap-2 text-sm font-semibold text-foreground">
              <BellOff className="h-4 w-4 text-primary" />
              Currently Suppressed
            </h3>
            <div className="flex flex-col gap-3">
              {suppressedNotifications.map((notif) => (
                <div
                  key={notif.id}
                  className="rounded-xl border border-primary/20 bg-primary/5 p-4"
                >
                  <div className="flex items-start gap-3">
                    <div className="relative">
                      <Avatar className="h-10 w-10">
                        <AvatarFallback className="bg-primary/10 text-primary text-xs">
                          {notif.initials}
                        </AvatarFallback>
                      </Avatar>
                      <div className="absolute -bottom-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full bg-primary">
                        <Heart className="h-2.5 w-2.5 text-primary-foreground" />
                      </div>
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <p className="text-sm font-semibold text-foreground">
                          {notif.friend}
                        </p>
                        <Badge variant="outline" className="border-primary/30 text-primary text-[10px]">
                          Suppressed
                        </Badge>
                      </div>
                      <p className="mt-0.5 text-xs text-muted-foreground">
                        {notif.originalReminder} &middot; {notif.amount}
                      </p>
                      <div className="mt-2 flex items-center gap-2">
                        <div className="flex items-center gap-1.5 rounded-full bg-card px-2.5 py-1">
                          <MapPin className="h-3 w-3 text-primary" />
                          <span className="text-[10px] font-medium text-foreground">
                            {notif.reason}
                          </span>
                        </div>
                        <span className="text-[10px] text-muted-foreground">
                          {notif.time}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* AI Decision Log */}
          <div>
            <h3 className="mb-3 flex items-center gap-2 text-sm font-semibold text-foreground">
              <Eye className="h-4 w-4 text-primary" />
              AI Decision Log
            </h3>
            <div className="rounded-xl border border-border bg-card overflow-hidden">
              <div className="grid grid-cols-[auto_1fr_1fr_auto_auto] gap-4 border-b border-border bg-muted/50 px-4 py-2.5 text-[10px] font-medium text-muted-foreground">
                <span>Action</span>
                <span>Friend</span>
                <span>Context</span>
                <span>Time</span>
                <span>Status</span>
              </div>
              {recentDecisions.map((decision) => (
                <div
                  key={decision.id}
                  className="grid grid-cols-[auto_1fr_1fr_auto_auto] gap-4 items-center border-b border-border px-4 py-3 last:border-0"
                >
                  <div className={cn(
                    "flex h-6 w-6 items-center justify-center rounded-full",
                    decision.action === "Suppressed" ? "bg-primary/10" : "bg-muted"
                  )}>
                    {decision.action === "Suppressed" ? (
                      <BellOff className="h-3 w-3 text-primary" />
                    ) : (
                      <Bell className="h-3 w-3 text-muted-foreground" />
                    )}
                  </div>
                  <span className="text-xs font-medium text-foreground">
                    {decision.friend}
                  </span>
                  <span className="text-xs text-muted-foreground">
                    {decision.location}
                  </span>
                  <span className="text-[10px] text-muted-foreground">
                    {decision.time}
                  </span>
                  <Badge
                    variant={decision.status === "active" ? "default" : "secondary"}
                    className="text-[10px]"
                  >
                    {decision.status === "active" ? "Active" : decision.status === "sent" ? "Delivered" : "Resolved"}
                  </Badge>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right: Settings */}
        <div className="flex flex-col gap-5">
          {/* Sensitive Zones Configuration */}
          <div className="rounded-2xl border border-border bg-card p-5">
            <div className="flex items-center gap-2 mb-4">
              <MapPin className="h-4 w-4 text-primary" />
              <h3 className="text-sm font-semibold text-foreground">
                Suppression Zones
              </h3>
            </div>
            <div className="flex flex-col gap-3">
              {zones.map((zone, index) => (
                <div
                  key={zone.label}
                  className="flex items-center justify-between rounded-xl bg-muted/50 p-3"
                >
                  <div className="flex items-center gap-3">
                    <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10">
                      <zone.icon className="h-4 w-4 text-primary" />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-foreground">
                        {zone.label}
                      </p>
                      <p className="text-[10px] text-muted-foreground">
                        {zone.count} locations tracked
                      </p>
                    </div>
                  </div>
                  <Switch
                    checked={zone.enabled}
                    onCheckedChange={() => toggleZone(index)}
                    className="data-[state=checked]:bg-primary"
                  />
                </div>
              ))}
            </div>
          </div>

          {/* AI Engine Status */}
          <div className="rounded-2xl border border-border bg-card p-5">
            <div className="flex items-center gap-2 mb-4">
              <Shield className="h-4 w-4 text-primary" />
              <h3 className="text-sm font-semibold text-foreground">
                AI Engine Status
              </h3>
            </div>
            <div className="flex flex-col gap-3">
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">Context AI Engine</span>
                <div className="flex items-center gap-1.5">
                  <div className="h-2 w-2 rounded-full bg-chart-5 animate-pulse" />
                  <span className="text-xs font-medium text-chart-5">Online</span>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">Google Places API</span>
                <div className="flex items-center gap-1.5">
                  <div className="h-2 w-2 rounded-full bg-chart-5" />
                  <span className="text-xs font-medium text-chart-5">Connected</span>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">Radar SDK</span>
                <div className="flex items-center gap-1.5">
                  <div className="h-2 w-2 rounded-full bg-chart-5" />
                  <span className="text-xs font-medium text-chart-5">Active</span>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">Notification Service</span>
                <div className="flex items-center gap-1.5">
                  <div className="h-2 w-2 rounded-full bg-chart-5" />
                  <span className="text-xs font-medium text-chart-5">Ready</span>
                </div>
              </div>
            </div>
          </div>

          {/* Workflow State */}
          <div className="rounded-2xl border border-border bg-card p-5">
            <div className="flex items-center gap-2 mb-4">
              <Clock className="h-4 w-4 text-primary" />
              <h3 className="text-sm font-semibold text-foreground">
                Notification Workflow
              </h3>
            </div>
            <div className="flex flex-col gap-2">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-primary" />
                <span className="text-xs text-foreground">CheckLocation</span>
                <span className="text-[10px] text-muted-foreground ml-auto">State entered</span>
              </div>
              <div className="ml-2 h-3 w-px bg-primary/30" />
              <div className="flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-primary" />
                <span className="text-xs text-foreground">Analyze Category</span>
                <span className="text-[10px] text-muted-foreground ml-auto">Sensitive detected</span>
              </div>
              <div className="ml-2 h-3 w-px bg-primary/30" />
              <div className="flex items-center gap-2">
                <div className="flex h-4 w-4 items-center justify-center rounded-full bg-primary">
                  <BellOff className="h-2.5 w-2.5 text-primary-foreground" />
                </div>
                <span className="text-xs font-medium text-primary">Suppressed</span>
                <span className="text-[10px] text-muted-foreground ml-auto">Current state</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
