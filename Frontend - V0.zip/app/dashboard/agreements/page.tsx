"use client"

import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  FileText,
  Link2,
  Shield,
  CheckCircle2,
  Clock,
  Plus,
  Hash,
  Calendar,
  DollarSign,
  ExternalLink,
} from "lucide-react"
import { cn } from "@/lib/utils"

const agreements = [
  {
    id: "AGR-001",
    title: "Monthly Rent Split",
    parties: [
      { name: "You", initials: "JP" },
      { name: "Jordan R.", initials: "JR" },
      { name: "Taylor P.", initials: "TP" },
    ],
    amount: "$800.00/month",
    status: "active",
    verified: true,
    hash: "0x7f3a...b2c1",
    created: "Jan 15, 2026",
    nextPayment: "Mar 1, 2026",
    description: "Equal three-way split for apartment rent at 425 Oak St.",
  },
  {
    id: "AGR-002",
    title: "Personal Loan Agreement",
    parties: [
      { name: "You", initials: "JP" },
      { name: "Sarah M.", initials: "SM" },
    ],
    amount: "$500.00",
    status: "active",
    verified: true,
    hash: "0x9e2d...a4f8",
    created: "Feb 1, 2026",
    nextPayment: "Mar 15, 2026",
    description: "Sarah borrowed $500 with 6-month repayment plan. Trust score-backed.",
  },
  {
    id: "AGR-003",
    title: "Trip Expense Pool",
    parties: [
      { name: "You", initials: "JP" },
      { name: "Alex K.", initials: "AK" },
      { name: "Sarah M.", initials: "SM" },
      { name: "Jordan R.", initials: "JR" },
    ],
    amount: "$1,200.00 total",
    status: "completed",
    verified: true,
    hash: "0x4b1c...e7d3",
    created: "Dec 10, 2025",
    nextPayment: "Settled",
    description: "Ski trip group expense pool. All contributions verified.",
  },
  {
    id: "AGR-004",
    title: "Equipment Purchase Split",
    parties: [
      { name: "You", initials: "JP" },
      { name: "Taylor P.", initials: "TP" },
    ],
    amount: "$350.00",
    status: "pending",
    verified: false,
    hash: "Pending...",
    created: "Feb 18, 2026",
    nextPayment: "Awaiting signature",
    description: "Shared purchase of home office equipment. Awaiting Taylor's approval.",
  },
  {
    id: "AGR-005",
    title: "Monthly Utilities Pool",
    parties: [
      { name: "You", initials: "JP" },
      { name: "Jordan R.", initials: "JR" },
      { name: "Taylor P.", initials: "TP" },
    ],
    amount: "$110.00/month",
    status: "active",
    verified: true,
    hash: "0x1f8e...c5a2",
    created: "Jan 20, 2026",
    nextPayment: "Mar 5, 2026",
    description: "Electric + water + internet split for shared apartment.",
  },
]

export default function AgreementsPage() {
  return (
    <div className="flex flex-col gap-6 p-4 lg:p-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1
            className="text-2xl font-bold text-foreground"
            style={{ fontFamily: "var(--font-heading)" }}
          >
            Digital Agreements
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Blockchain-verified contracts that replace vague oral promises
          </p>
        </div>
        <Button className="gap-2">
          <Plus className="h-4 w-4" />
          <span className="hidden sm:inline">New Agreement</span>
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
        <div className="rounded-xl border border-border bg-card p-4">
          <div className="flex items-center gap-2 mb-2">
            <FileText className="h-4 w-4 text-primary" />
            <span className="text-xs text-muted-foreground">Total</span>
          </div>
          <p className="text-2xl font-bold text-foreground">5</p>
        </div>
        <div className="rounded-xl border border-border bg-card p-4">
          <div className="flex items-center gap-2 mb-2">
            <CheckCircle2 className="h-4 w-4 text-chart-5" />
            <span className="text-xs text-muted-foreground">Active</span>
          </div>
          <p className="text-2xl font-bold text-foreground">3</p>
        </div>
        <div className="rounded-xl border border-border bg-card p-4">
          <div className="flex items-center gap-2 mb-2">
            <Link2 className="h-4 w-4 text-primary" />
            <span className="text-xs text-muted-foreground">Verified</span>
          </div>
          <p className="text-2xl font-bold text-foreground">4</p>
        </div>
        <div className="rounded-xl border border-border bg-card p-4">
          <div className="flex items-center gap-2 mb-2">
            <Clock className="h-4 w-4 text-muted-foreground" />
            <span className="text-xs text-muted-foreground">Pending</span>
          </div>
          <p className="text-2xl font-bold text-foreground">1</p>
        </div>
      </div>

      {/* Agreements List */}
      <div className="flex flex-col gap-4">
        {agreements.map((agreement) => (
          <div
            key={agreement.id}
            className={cn(
              "rounded-2xl border border-border bg-card p-5 transition-all hover:border-primary/20 hover:shadow-sm",
              agreement.status === "pending" && "border-dashed"
            )}
          >
            <div className="flex items-start justify-between gap-4">
              <div className="flex-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="text-base font-semibold text-foreground">
                    {agreement.title}
                  </h3>
                  <Badge
                    variant={
                      agreement.status === "active"
                        ? "default"
                        : agreement.status === "completed"
                          ? "secondary"
                          : "outline"
                    }
                    className="text-[10px]"
                  >
                    {agreement.status === "active"
                      ? "Active"
                      : agreement.status === "completed"
                        ? "Completed"
                        : "Pending Signature"}
                  </Badge>
                  {agreement.verified && (
                    <div className="flex items-center gap-1 text-primary">
                      <Shield className="h-3 w-3" />
                      <span className="text-[10px] font-medium">Verified</span>
                    </div>
                  )}
                </div>
                <p className="mt-1.5 text-sm text-muted-foreground">
                  {agreement.description}
                </p>

                <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
                  <div className="flex items-center gap-2">
                    <DollarSign className="h-3.5 w-3.5 text-muted-foreground" />
                    <div>
                      <p className="text-[10px] text-muted-foreground">Amount</p>
                      <p className="text-xs font-medium text-foreground">{agreement.amount}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Calendar className="h-3.5 w-3.5 text-muted-foreground" />
                    <div>
                      <p className="text-[10px] text-muted-foreground">Next Payment</p>
                      <p className="text-xs font-medium text-foreground">{agreement.nextPayment}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Hash className="h-3.5 w-3.5 text-muted-foreground" />
                    <div>
                      <p className="text-[10px] text-muted-foreground">Hash</p>
                      <p className="text-xs font-mono text-foreground">{agreement.hash}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Calendar className="h-3.5 w-3.5 text-muted-foreground" />
                    <div>
                      <p className="text-[10px] text-muted-foreground">Created</p>
                      <p className="text-xs font-medium text-foreground">{agreement.created}</p>
                    </div>
                  </div>
                </div>

                <div className="mt-4 flex items-center gap-2">
                  <span className="text-[10px] text-muted-foreground">Parties:</span>
                  <div className="flex -space-x-1.5">
                    {agreement.parties.map((party) => (
                      <Avatar key={party.name} className="h-6 w-6 border-2 border-card">
                        <AvatarFallback className="bg-muted text-[8px] text-muted-foreground">
                          {party.initials}
                        </AvatarFallback>
                      </Avatar>
                    ))}
                  </div>
                  <span className="text-[10px] text-muted-foreground">
                    {agreement.parties.map(p => p.name).join(", ")}
                  </span>
                </div>
              </div>

              <Button variant="ghost" size="icon" className="shrink-0">
                <ExternalLink className="h-4 w-4" />
                <span className="sr-only">View agreement details</span>
              </Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
