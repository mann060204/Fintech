"use client"

import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  Award,
  Star,
  Trophy,
  Zap,
  Users,
  Clock,
  CheckCircle2,
  Lock,
  Gift,
} from "lucide-react"
import { cn } from "@/lib/utils"

const tiers = [
  {
    name: "Common",
    subtitle: "First Steps",
    color: "bg-muted",
    borderColor: "border-border",
    textColor: "text-muted-foreground",
    icon: Award,
    progress: 100,
    unlocked: true,
    benefits: ["Basic trust badge", "Group creation", "5 agreements/month"],
    requirements: "5 on-time payments",
  },
  {
    name: "Premium",
    subtitle: "Trust Builder",
    color: "bg-primary/10",
    borderColor: "border-primary",
    textColor: "text-primary",
    icon: Star,
    progress: 73,
    unlocked: false,
    benefits: [
      "Priority reminders",
      "Enhanced trust badge",
      "Unlimited agreements",
      "Higher loan limits",
    ],
    requirements: "25 on-time payments + Score 600+",
  },
  {
    name: "Rare",
    subtitle: "CEO Endorsement",
    color: "bg-accent",
    borderColor: "border-accent",
    textColor: "text-accent-foreground",
    icon: Trophy,
    progress: 22,
    unlocked: false,
    benefits: [
      "CEO-level trust badge",
      "Maximum loan limits",
      "Community leader status",
      "Exclusive rewards",
      "Beta feature access",
    ],
    requirements: "100 on-time payments + Score 900+",
  },
]

const achievements = [
  {
    id: 1,
    title: "First Payment",
    description: "Made your first on-time payment",
    icon: Zap,
    earned: true,
    date: "Jan 2, 2026",
    tier: "Common",
  },
  {
    id: 2,
    title: "Team Player",
    description: "Joined 3 expense groups",
    icon: Users,
    earned: true,
    date: "Jan 15, 2026",
    tier: "Common",
  },
  {
    id: 3,
    title: "Streak Master",
    description: "10 consecutive on-time payments",
    icon: Clock,
    earned: true,
    date: "Feb 5, 2026",
    tier: "Common",
  },
  {
    id: 4,
    title: "Trust Ambassador",
    description: "Get 5 peer endorsements",
    icon: Star,
    earned: true,
    date: "Feb 12, 2026",
    tier: "Premium",
  },
  {
    id: 5,
    title: "Agreement Architect",
    description: "Create 10 blockchain agreements",
    icon: CheckCircle2,
    earned: false,
    date: null,
    tier: "Premium",
  },
  {
    id: 6,
    title: "Community Pillar",
    description: "Help 20 friends settle debts",
    icon: Gift,
    earned: false,
    date: null,
    tier: "Rare",
  },
]

export default function RewardsPage() {
  return (
    <div className="flex flex-col gap-6 p-4 lg:p-6">
      {/* Header */}
      <div>
        <h1
          className="text-2xl font-bold text-foreground"
          style={{ fontFamily: "var(--font-heading)" }}
        >
          Gamified Rewards
        </h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Earn candy-themed achievements for on-time payments and building trust
        </p>
      </div>

      {/* Current Progress */}
      <div className="rounded-2xl border border-primary bg-card p-6 shadow-lg shadow-primary/5">
        <div className="flex items-center justify-between mb-4">
          <div>
            <p className="text-sm text-muted-foreground">Current Tier</p>
            <h2 className="text-xl font-bold text-foreground">Common</h2>
          </div>
          <div className="text-right">
            <p className="text-sm text-muted-foreground">Next Tier</p>
            <h2 className="text-xl font-bold text-primary">Premium</h2>
          </div>
        </div>
        <Progress value={73} className="h-3" />
        <div className="mt-2 flex items-center justify-between">
          <span className="text-xs text-muted-foreground">18/25 payments</span>
          <span className="text-xs font-medium text-primary">73% to Premium</span>
        </div>
      </div>

      {/* Tier Cards */}
      <div className="grid gap-4 sm:grid-cols-3">
        {tiers.map((tier) => (
          <div
            key={tier.name}
            className={cn(
              "rounded-2xl border-2 bg-card p-5 transition-all",
              tier.unlocked ? tier.borderColor : "border-border",
              tier.unlocked && "shadow-lg"
            )}
          >
            <div className="flex items-center gap-3 mb-4">
              <div className={cn("flex h-12 w-12 items-center justify-center rounded-xl", tier.color)}>
                <tier.icon className={cn("h-6 w-6", tier.textColor)} />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-foreground">{tier.name}</h3>
                <p className={cn("text-xs font-medium", tier.textColor)}>{tier.subtitle}</p>
              </div>
              {tier.unlocked && (
                <Badge className="ml-auto text-[10px]">Unlocked</Badge>
              )}
            </div>

            <div className="mb-4">
              <Progress value={tier.progress} className="h-1.5" />
              <p className="mt-1 text-right text-[10px] text-muted-foreground">
                {tier.progress}%
              </p>
            </div>

            <p className="text-[10px] text-muted-foreground mb-3">
              Requires: {tier.requirements}
            </p>

            <div className="flex flex-col gap-1.5">
              {tier.benefits.map((benefit) => (
                <div key={benefit} className="flex items-center gap-2">
                  <CheckCircle2
                    className={cn(
                      "h-3 w-3 shrink-0",
                      tier.unlocked ? "text-primary" : "text-muted-foreground"
                    )}
                  />
                  <span className="text-xs text-foreground">{benefit}</span>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Achievements */}
      <div>
        <h2
          className="mb-4 text-lg font-bold text-foreground"
          style={{ fontFamily: "var(--font-heading)" }}
        >
          Achievements
        </h2>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {achievements.map((achievement) => (
            <div
              key={achievement.id}
              className={cn(
                "rounded-xl border border-border bg-card p-4 transition-all",
                achievement.earned
                  ? "hover:border-primary/20 hover:shadow-sm"
                  : "opacity-60"
              )}
            >
              <div className="flex items-start gap-3">
                <div
                  className={cn(
                    "flex h-10 w-10 shrink-0 items-center justify-center rounded-xl",
                    achievement.earned ? "bg-primary/10" : "bg-muted"
                  )}
                >
                  {achievement.earned ? (
                    <achievement.icon className="h-5 w-5 text-primary" />
                  ) : (
                    <Lock className="h-4 w-4 text-muted-foreground" />
                  )}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-semibold text-foreground">
                      {achievement.title}
                    </p>
                    <Badge
                      variant="outline"
                      className={cn(
                        "text-[10px]",
                        achievement.tier === "Premium" && "border-primary text-primary",
                        achievement.tier === "Rare" && "border-accent-foreground text-accent-foreground"
                      )}
                    >
                      {achievement.tier}
                    </Badge>
                  </div>
                  <p className="mt-0.5 text-xs text-muted-foreground">
                    {achievement.description}
                  </p>
                  {achievement.earned && achievement.date && (
                    <p className="mt-1.5 text-[10px] text-primary font-medium">
                      Earned {achievement.date}
                    </p>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
