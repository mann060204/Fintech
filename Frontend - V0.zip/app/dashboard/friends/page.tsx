"use client"

import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  UserPlus,
  Search,
  Heart,
  BellOff,
  MapPin,
  Shield,
  TrendingUp,
  ArrowUpRight,
  ArrowDownRight,
} from "lucide-react"
import { cn } from "@/lib/utils"

const friends = [
  {
    name: "Sarah Martinez",
    initials: "SM",
    trustScore: 810,
    status: "online",
    balance: 72.50,
    direction: "owed",
    mutualGroups: 3,
    sensitiveZone: false,
    lastActive: "Active now",
  },
  {
    name: "Alex Kim",
    initials: "AK",
    trustScore: 695,
    status: "sensitive",
    balance: 141.00,
    direction: "owe",
    mutualGroups: 2,
    sensitiveZone: true,
    sensitiveLocation: "Hospital",
    lastActive: "2h ago",
  },
  {
    name: "Jordan Rodriguez",
    initials: "JR",
    trustScore: 742,
    status: "online",
    balance: 22.50,
    direction: "owed",
    mutualGroups: 4,
    sensitiveZone: false,
    lastActive: "1h ago",
  },
  {
    name: "Taylor Park",
    initials: "TP",
    trustScore: 588,
    status: "offline",
    balance: 0,
    direction: "settled",
    mutualGroups: 2,
    sensitiveZone: false,
    lastActive: "3d ago",
  },
  {
    name: "Morgan Lewis",
    initials: "ML",
    trustScore: 920,
    status: "online",
    balance: 350.00,
    direction: "owed",
    mutualGroups: 1,
    sensitiveZone: false,
    lastActive: "Active now",
  },
  {
    name: "Casey Chen",
    initials: "CC",
    trustScore: 445,
    status: "sensitive",
    balance: 65.00,
    direction: "owe",
    mutualGroups: 1,
    sensitiveZone: true,
    sensitiveLocation: "Police Station",
    lastActive: "5h ago",
  },
]

export default function FriendsPage() {
  return (
    <div className="flex flex-col gap-6 p-4 lg:p-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1
            className="text-2xl font-bold text-foreground"
            style={{ fontFamily: "var(--font-heading)" }}
          >
            Friends
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {friends.length} friends &middot; {friends.filter(f => f.sensitiveZone).length} in sensitive zones
          </p>
        </div>
        <div className="flex gap-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input placeholder="Search friends..." className="h-9 pl-9 w-56" />
          </div>
          <Button className="gap-2">
            <UserPlus className="h-4 w-4" />
            <span className="hidden sm:inline">Add Friend</span>
          </Button>
        </div>
      </div>

      {/* Friends List */}
      <div className="flex flex-col gap-3">
        {friends.map((friend) => (
          <div
            key={friend.name}
            className={cn(
              "rounded-xl border border-border bg-card p-4 transition-all hover:border-primary/20 hover:shadow-sm",
              friend.sensitiveZone && "border-primary/20 bg-primary/5"
            )}
          >
            <div className="flex items-center gap-4">
              {/* Avatar */}
              <div className="relative">
                <Avatar className="h-12 w-12">
                  <AvatarFallback className="bg-muted text-muted-foreground text-sm">
                    {friend.initials}
                  </AvatarFallback>
                </Avatar>
                <div
                  className={cn(
                    "absolute -bottom-0.5 -right-0.5 h-3.5 w-3.5 rounded-full border-2 border-card",
                    friend.status === "online" && "bg-chart-5",
                    friend.status === "sensitive" && "bg-primary",
                    friend.status === "offline" && "bg-muted-foreground/40"
                  )}
                />
              </div>

              {/* Info */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="text-sm font-semibold text-foreground">
                    {friend.name}
                  </h3>
                  {friend.sensitiveZone && (
                    <Badge
                      variant="outline"
                      className="gap-1 border-primary/30 text-primary text-[10px]"
                    >
                      <Heart className="h-2.5 w-2.5" />
                      In a sensitive zone -- reminders paused
                    </Badge>
                  )}
                </div>

                <div className="mt-1 flex items-center gap-3 flex-wrap">
                  <div className="flex items-center gap-1">
                    <Shield className="h-3 w-3 text-primary" />
                    <span className="text-[10px] text-muted-foreground">
                      Score: {friend.trustScore}
                    </span>
                  </div>
                  <span className="text-[10px] text-muted-foreground">
                    {friend.mutualGroups} mutual groups
                  </span>
                  <span className="text-[10px] text-muted-foreground">
                    {friend.lastActive}
                  </span>
                </div>

                {friend.sensitiveZone && friend.sensitiveLocation && (
                  <div className="mt-2 flex items-center gap-2">
                    <div className="flex items-center gap-1.5 rounded-full bg-card px-2.5 py-1 border border-primary/10">
                      <MapPin className="h-3 w-3 text-primary" />
                      <span className="text-[10px] font-medium text-foreground">
                        Near {friend.sensitiveLocation}
                      </span>
                    </div>
                    <div className="flex items-center gap-1 text-primary">
                      <BellOff className="h-3 w-3" />
                      <span className="text-[10px]">Notifications suppressed</span>
                    </div>
                  </div>
                )}
              </div>

              {/* Balance */}
              <div className="text-right shrink-0">
                {friend.direction !== "settled" ? (
                  <>
                    <div className="flex items-center gap-1 justify-end">
                      {friend.direction === "owed" ? (
                        <ArrowUpRight className="h-3.5 w-3.5 text-chart-5" />
                      ) : (
                        <ArrowDownRight className="h-3.5 w-3.5 text-destructive-foreground" />
                      )}
                      <span
                        className={cn(
                          "text-sm font-bold",
                          friend.direction === "owed"
                            ? "text-chart-5"
                            : "text-destructive-foreground"
                        )}
                      >
                        ${friend.balance.toFixed(2)}
                      </span>
                    </div>
                    <p className="text-[10px] text-muted-foreground">
                      {friend.direction === "owed" ? "owes you" : "you owe"}
                    </p>
                  </>
                ) : (
                  <div>
                    <span className="text-sm font-medium text-muted-foreground">Settled</span>
                    <p className="text-[10px] text-chart-5">All clear</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
