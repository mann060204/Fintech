import { ExpenseFeed } from "@/components/dashboard/expense-feed"
import { FinancialHealth } from "@/components/dashboard/financial-health"
import { DashboardOverview } from "@/components/dashboard/overview"

export default function DashboardPage() {
  return (
    <div className="flex flex-col gap-6 p-4 lg:p-6">
      {/* Overview row */}
      <DashboardOverview />

      {/* Three-pane content: Center feed + Right sidebar */}
      <div className="grid gap-6 lg:grid-cols-[1fr_320px]">
        {/* Center: Expense Feed */}
        <ExpenseFeed />

        {/* Right: Financial Health Sidebar */}
        <div className="hidden lg:block">
          <FinancialHealth />
        </div>
      </div>
    </div>
  )
}
