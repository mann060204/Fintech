import { Navbar } from "@/components/landing/navbar"
import { HeroSection } from "@/components/landing/hero-section"
import { FeaturesSection } from "@/components/landing/features-section"
import { TrustScoreSection } from "@/components/landing/trust-score-section"
import { EmpathySection } from "@/components/landing/empathy-section"
import { CTASection } from "@/components/landing/cta-section"
import { Footer } from "@/components/landing/footer"

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main>
        <HeroSection />
        <FeaturesSection />
        <TrustScoreSection />
        <EmpathySection />
        <CTASection />
      </main>
      <Footer />
    </div>
  )
}
