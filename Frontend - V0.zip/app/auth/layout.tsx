import Link from "next/link"
import { Shield } from "lucide-react"

export default function AuthLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div className="flex min-h-screen">
      {/* Left: Branding Panel */}
      <div className="hidden w-1/2 flex-col justify-between bg-primary p-12 lg:flex">
        <Link href="/" className="flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary-foreground/20">
            <Shield className="h-5 w-5 text-primary-foreground" />
          </div>
          <span className="text-lg font-bold text-primary-foreground" style={{ fontFamily: "var(--font-heading)" }}>
            Project Platform
          </span>
        </Link>

        <div>
          <h2
            className="text-balance text-3xl font-bold text-primary-foreground"
            style={{ fontFamily: "var(--font-heading)" }}
          >
            Trust-First Finance, Powered by Empathy AI
          </h2>
          <p className="mt-4 max-w-md text-pretty text-base text-primary-foreground/70 leading-relaxed">
            Build your social collateral, split expenses with confidence, and
            let our AI understand when life needs a pause.
          </p>

          <div className="mt-8 flex flex-col gap-4">
            <div className="flex items-center gap-3">
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary-foreground/20">
                <svg className="h-4 w-4 text-primary-foreground" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
              </div>
              <span className="text-sm text-primary-foreground/80">Dynamic Trust Score (300-1000)</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary-foreground/20">
                <svg className="h-4 w-4 text-primary-foreground" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
              </div>
              <span className="text-sm text-primary-foreground/80">Blockchain-Verified Agreements</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary-foreground/20">
                <svg className="h-4 w-4 text-primary-foreground" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2"><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
              </div>
              <span className="text-sm text-primary-foreground/80">Location-Aware Empathy Engine</span>
            </div>
          </div>
        </div>

        <p className="text-xs text-primary-foreground/40">
          Secured by AES-256 encryption &middot; SOC 2 Type II compliant
        </p>
      </div>

      {/* Right: Auth Form */}
      <div className="flex w-full items-center justify-center bg-background px-4 py-12 lg:w-1/2">
        {children}
      </div>
    </div>
  )
}
